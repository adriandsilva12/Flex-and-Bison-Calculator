<program>    ::= <line> | <program> <line>
<line>       ::= <expression> EOL | EOL
<expression> ::= <expression> '+' <term> | <expression> '-' <term> | <term>
<term>       ::= <term> '*' <factor> | <term> '/' <factor> | <factor>
<factor>     ::= NUMBER | '(' <expression> ')'

In the CFG:

<program> represents the entire program, which consists of one or more <line>s.
<line> represents a single line of input, which can be an <expression> followed by EOL (End Of Line) or just an empty line (EOL).
<expression> represents an arithmetic expression, which can be the sum or difference of two <term>s or just a single <term>.
<term> represents a term, which can be the product or division of two <factor>s or just a single <factor>.
<factor> can be either a NUMBER (a numeric value) or an expression enclosed in parentheses.
This CFG defines the valid structure of input expressions for your calculator. It corresponds to the grammar rules you provided in your Bison code.
